package com.example.Proyect_Beta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectBetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
