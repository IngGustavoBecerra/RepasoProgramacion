package com.example.Proyect_Beta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectBetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectBetaApplication.class, args);
	}

}
